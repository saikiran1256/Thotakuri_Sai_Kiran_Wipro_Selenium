package StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MultipleSearch {
	WebDriver driver;
	@Given("the home page is open in the default browser")
	public void the_home_page_is_open_in_the_default_browser() {
	    driver=new ChromeDriver();
	    driver.get("http://zero.webappsecurity.com/index.html");
	    driver.manage().window().maximize();
	}

	@And("click search field")
	public void click_search_field() {
		driver.findElement(By.id("searchTerm")).click();
		
	}

	@And("^enter (.*) in the search field$")
	public void enter_in_the_search_field(String searcht) {
		driver.findElement(By.id("searchTerm")).sendKeys(searcht);
	}

	@And("submit the search")
	public void submit_the_search() {
		driver.findElement(By.id("searchTerm")).sendKeys(Keys.ENTER);  
	}

	@Then("^should show results related to (.*)$")
	public void should_show_results_related_to(String st) {
	 System.out.println("Search term "+st);   
	 driver.close();
	}

}
