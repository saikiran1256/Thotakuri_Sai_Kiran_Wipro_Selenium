package StepDefinition;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchSteps {
	WebDriver driver;
	@Given("home page should be available on default browser")
	public void home_page_should_be_available_on_default_browser() {
		driver =new ChromeDriver();
		driver.get("http://zero.webappsecurity.com/");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    
	}

	@When("click on search button and enter any input")
	public void click_on_search_button_and_enter_any_input() {
		WebElement search = driver.findElement(By.id("searchTerm"));
		search.click();
		search.sendKeys("Online Banking");
		search.sendKeys(Keys.ENTER);
	    
	}

	@Then("show search result")
	public void show_search_result() {
		System.out.println("search successfully");
	    
	}


}
